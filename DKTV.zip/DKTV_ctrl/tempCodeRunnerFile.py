plt.xticks([])
# plt.yticks([])