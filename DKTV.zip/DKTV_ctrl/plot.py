'''
===================================================================================
Description: Demo Results Plot
Project: Deep Koopman Representation for Nonlinear Time Varying Systems
Author: Wenjian Hao, Purdue University

Start at: Sep 2021
Last Revision: Jan 2022
===================================================================================
'''
import joblib

import numpy as np
import matplotlib.cm as cm
import matplotlib.pyplot as plt

from matplotlib.patches import Wedge
from mpl_toolkits.mplot3d import Axes3D
from scipy.ndimage.filters import gaussian_filter

SAVEDIR = 'SavedResults/demoreults.pkl'
NSAVEDIR = 'SavedResults/nonctrldemoreults.pkl'
data = joblib.load(SAVEDIR)
x = data[0,:]
xdot = data[1,:]
theta = data[2,:]
thetadot = data[3,:]
u = data[4,:]
muc = data[5,:]

Ndata = joblib.load(NSAVEDIR)
Nx = Ndata[0,:]
Nxdot = Ndata[1,:]
Ntheta = Ndata[2,:]
Nthetadot = Ndata[3,:]
Nu = Ndata[4,:]
Nmuc = Ndata[5,:]

def myplot(x, y, s, bins=1000):
    heatmap, xedges, yedges = np.histogram2d(x, y, bins=bins)
    heatmap = gaussian_filter(heatmap, sigma=s)
    extent = [xedges[0], xedges[-1], yedges[0], yedges[-1]]
    return heatmap.T, extent

plt.rcParams['figure.dpi'] = 100
fig = plt.figure(figsize=(19,4.6))
plt.rc('text', usetex=True)
plt.rc('font', family='serif')
labelsize = 15
plt.subplot(1,3,1)
plt.plot(np.zeros(theta.shape[0]), 'g:', label = 'the desired state', linewidth=2.0)
plt.plot(theta, 'b--', label = 'DKTV-based MPC', linewidth=2.0)
plt.plot(Ntheta, 'r--', label = 'uncontrolled system', linewidth=2.0)
plt.xlabel('Time Step',fontsize=labelsize)
plt.ylabel('$\\theta$ [rad]',fontsize=labelsize)
plt.ylim([-0.1, 0.36])
plt.tick_params(labelsize=labelsize)
plt.legend(loc='best', fontsize=labelsize)

plt.subplot(1,3,2)
plt.plot(np.zeros(theta.shape[0]), 'g:', label = 'the desired state', linewidth=2.0)
plt.plot(thetadot, 'b--', label = 'DKTV-based MPC', linewidth=2.0)
plt.plot(Nthetadot, 'r--', label = 'uncontrolled system', linewidth=2.0)
plt.xlabel('Time Step',fontsize=labelsize)
plt.ylabel('$\dot{\\theta}$ [rad/s]',fontsize=labelsize)
plt.ylim([-0.6, 1.6])
plt.tick_params(labelsize=labelsize)
plt.legend(loc='best', fontsize=labelsize)

ax = fig.add_subplot(1,3,3)
ax.plot(muc, 'b--', label = '$\mu_c(t)$', linewidth=2.0)
ax.set_xlabel('Time Step',fontsize=labelsize)
ax.set_ylabel('$\mu_c(t)$',fontsize=labelsize)
plt.tick_params(labelsize=labelsize)
plt.legend(loc='best', fontsize=labelsize)
ax2 = ax.twinx()
ax2.plot(u, 'r--', label = 'control input', linewidth=2.0)
ax2.set_ylabel('control input',fontsize=labelsize)
plt.tick_params(labelsize=labelsize)
plt.legend(loc='lower right', fontsize=labelsize)
# plt.subplot(1,3,3)
# plt.plot(muc, 'b--', label = '$\mu_c$', linewidth=2.0)
# plt.plot(u, 'r--', label = 'control input', linewidth=2.0)
# plt.xlabel('Time Step',fontsize=labelsize)
# plt.ylabel('control input',fontsize=labelsize)
# plt.tick_params(labelsize=labelsize)
# plt.legend(loc='best', fontsize=labelsize)



sigmas = [16, 32, 64]
gausi = sigmas[1]
plt.rcParams['figure.dpi'] = 100
plt.figure(figsize=(10,4))
plt.rc('text', usetex=True)
plt.rc('font', family='serif')

img, extent = myplot(muc, theta, gausi)
plt.subplot(1,2,2)
plt.imshow(img, origin='lower', cmap='turbo')
im1 = plt.scatter(muc, theta, c=u, cmap='turbo')
plt.colorbar(im1)
plt.xlabel('$\mu_c$',fontsize=15)
plt.ylabel('$\\theta$',fontsize=15)
plt.tick_params(labelsize=15)
plt.xticks([])
plt.yticks([])
# plt.legend(loc='best', fontsize=12)

img1, extent2 = myplot(thetadot, theta, gausi)
plt.subplot(1,2,1)
plt.scatter(thetadot, theta, linewidth=2.0)
plt.imshow(img1, origin='lower', cmap='turbo')
# plt.scatter([500], [500], marker='x', c="black" , label='goal position')
im2 = plt.scatter(theta, thetadot, c=muc, cmap='turbo')
plt.colorbar(im2)
plt.ylabel('$\\theta$',fontsize=15)
plt.xlabel('$\dot{\\theta}$',fontsize=15)
plt.tick_params(labelsize=15)
plt.xticks([])
plt.yticks([])
# plt.legend(loc='best', fontsize=12)

plt.show()