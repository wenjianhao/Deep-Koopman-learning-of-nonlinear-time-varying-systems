'''
===================================================================================
Description: Demo based on the MPC
Project: Deep Koopman Representation for Nonlinear Time Varying Systems
Author: Wenjian Hao, Purdue University

Start at: Sep 2021
Last Revision: Jan 2022
===================================================================================
'''

import gym
import torch
import joblib
import control

import numpy as np
import matplotlib.pyplot as plt

from LNN import LNN
from PCT import PCTMPC
from gym import wrappers
from mpl_toolkits.mplot3d import Axes3D

# load files and model
load_name = 'SavedResults/nnbasis/'
fileastack = 'SavedResults/Astack.pkl'
filebstack = 'SavedResults/Bstack.pkl'
filecstack = 'SavedResults/Cstack.pkl'
Astack = joblib.load(fileastack)
Bstack = joblib.load(filebstack)
Cstack = joblib.load(filecstack)

# MPC controller
class TEST():
    def __init__(self, Numgame, batchsize, dim_states, dim_lifting):
        # Initialize recording lists
        self.SAVEDIR = 'SavedResults/demoreults.pkl'
        self.Ngames = Numgame
        self.batchsize = batchsize
        self.dim_states = dim_states
        self.dim_lifting = dim_lifting
        self.total_steps = 0
        self.x = []
        self.xdot = []
        self.theta = []
        self.thetadot = []
        self.u = []
        self.mu = []
        # Build environment
        # ENV = gym.make('CartPole-v0')
        # vid = video_recorder.VideoRecorder(ENV,path="./record/vid.mp4")
        ENV = wrappers.Monitor(gym.make('CartPole-v0'), './record', force=True) # save videos or not # 
        # MPC set up
        # time_horizon = 48
        # Q = np.diag([.01,48,152,112])
        # R = np.diag([1])
        time_horizon = 48
        Q = np.diag([.01,48,152,112])
        R = np.diag([1])
        # constrains
        umax=np.array([10])
        umin=np.array([-10])

        for i in range(self.Ngames):
            obs = ENV.reset()
            done = False
            timestep = 0
            goalstate = np.array([0,0,0,0])
            goalstate = torch.from_numpy(goalstate.T).float()
            while not done:
                # set up MPC for time varying DKTV
                dynind = int(np.floor(timestep/self.batchsize))
                # print('current index is: ', timestep)
                # print('current index is: ', dynind)
                self.A = np.matrix(Astack[:,:,dynind])
                self.B = np.matrix(Bstack[:,:,dynind])
                self.C = np.matrix(Cstack[:,:,dynind])                        
                Q_lifted = self.C.T*Q*self.C     
                Qf = Q_lifted * 2
                mpc = PCTMPC(self.A, self.B, Q_lifted, R, Qf, umax=umax, umin=umin)
                # load the nn basis
                basis = load_name + str(dynind) + 'liftnetwork.pth'
                checkpoint = torch.load(basis, map_location=torch.device('cpu'))
                nnlifting = LNN(dim_input=self.dim_states, dim_output=self.dim_lifting)
                nnlifting.load_state_dict(checkpoint['model_lifting'])
                # koopman space
                goal_state_lifted = nnlifting.forward(goalstate).cpu().detach().numpy()
                cur_state_lifted = nnlifting.forward(torch.from_numpy(obs.T).float()).cpu().detach().numpy()
                cur_state_lifted = cur_state_lifted - goal_state_lifted
                # mpc planning
                try:
                    x_mpc, u_mpc = mpc.compute_policy_gains(N=time_horizon,x_t0=cur_state_lifted.T)
                except:
                    done = True
                u= u_mpc[0]
                # u=0
                inlist = np.array([u, timestep])
                obs, reward, done, muc = ENV.step(inlist)
                self.x.append(obs[0])
                self.xdot.append(obs[1])
                self.theta.append(obs[2])
                self.thetadot.append(obs[3])
                self.u.append(u)
                self.mu.append(muc)
                # if u == 1:
                #     self.u.append(10)
                # else:
                #     self.u.append(-10)

                self.total_steps += 1                
                timestep += 1
                if timestep >= 120:
                    done = True
                    break
                ENV.render()
        ENV.close()

        #==================
        # Figures Plotting
        #==================
        # Trajectory Plotting
        plt.rcParams['figure.dpi'] = 100
        plt.figure(figsize=(12,8))
        plt.title('Result', fontsize=12)

        # plt.subplot(2,1,1)
        # plt.plot(self.x) 
        # plt.xlabel('Time Step',fontsize=12)
        # plt.ylabel('x',fontsize=12)

        plt.subplot(2,2,3)
        plt.plot(self.xdot)
        plt.xlabel('Time Step',fontsize=12)
        plt.ylabel('$\dot{x}$',fontsize=12)

        plt.subplot(2,2,1)
        plt.plot(self.theta)
        plt.xlabel('Time Step',fontsize=12)
        plt.ylabel('$\\theta$ [rad]',fontsize=12)

        plt.subplot(2,2,2)
        plt.plot(self.thetadot)
        plt.xlabel('Time Step',fontsize=12)
        plt.ylabel('$\dot{\\theta}$ [rad/s]',fontsize=12)

        plt.subplot(2,2,4)
        plt.plot(self.mu)
        plt.plot( self.u)
        plt.xlabel('$\mu_c$',fontsize=12)
        plt.ylabel('u',fontsize=12)

        plt.show()
        

        history = np.zeros((6, self.total_steps))
        history[0,:] = self.x
        history[1,:] = self.xdot
        history[2,:] = self.theta
        history[3,:] = self.thetadot
        history[4,:] = self.u
        history[5,:] = self.mu
        joblib.dump(history, self.SAVEDIR)
        print('Saved Results')

if __name__=='__main__':
    run = TEST(1,10,4,10)