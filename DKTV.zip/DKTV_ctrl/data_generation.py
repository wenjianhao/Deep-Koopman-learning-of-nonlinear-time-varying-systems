'''
===================================================================================
Description: Data Generation for the time varying cartpole simulation env
Project: Deep Koopman Representation for Nonlinear Time Varying Systems
Author: Wenjian Hao, Purdue University

Start at: Sep 2021
Last Revision: Jan 2022

Training data format:

 | x11 x12 ... x1t |
 | x21 x12 ... x1t |
 | ... ... ... ... |
 | xn1 xn2 ... xnt |
 | u11 u12 ... u1t |
 | ... ... ... ... |
 | um1 um2 ... umt |

 n: dimension of the states
 m: dimension of the control
 t: time series 
===================================================================================
'''
import gym
import joblib
from gym import wrappers

import numpy as np
import matplotlib.pyplot as plt

class TVCartpole():
    def __init__(self, Ngames):
        # Build environment
        self.SAVEDIR = 'SavedResults/trainingdata.pkl'
        self.total_steps = 0
        self.Ngames = Ngames
        self.x = []
        self.xdot = []
        self.theta = []
        self.thetadot = []
        self.u = []

        ENV = wrappers.Monitor(gym.make('CartPole-v0'), 'record', force=True) # install gym==0.18.3 if you can not use gym.wrappers to record videos
        # ENV = gym.make('CartPole-v0')
        for i in range(self.Ngames):
            obs = ENV.reset()
            done = False
            timestep = 0

            while not done:
                u = np.random.randint(2, size=1).squeeze()
                inlist = np.array([u, timestep])
                obs, reward, done, info = ENV.step(inlist)
                self.x.append(obs[0])
                self.xdot.append(obs[1])
                self.theta.append(obs[2])
                self.thetadot.append(obs[3])
                if u == 1:
                    self.u.append(10)
                else:
                    self.u.append(-10)

                self.total_steps += 1                
                timestep += 1

                ENV.render()

        #==================
        # Figures Plotting
        #==================
        # Trajectory Plotting
        plt.rcParams['figure.dpi'] = 100
        plt.figure(figsize=(6,16))
        plt.title('Training Data', fontsize=12)

        plt.subplot(5,1,1)
        plt.plot(self.x) 
        plt.xlabel('Time Step',fontsize=12)
        plt.ylabel('x',fontsize=12)

        plt.subplot(5,1,2)
        plt.plot(self.xdot)
        plt.xlabel('Time Step',fontsize=12)
        plt.ylabel('$\dot{x}$',fontsize=12)

        plt.subplot(5,1,3)
        plt.plot(self.theta)
        plt.xlabel('Time Step',fontsize=12)
        plt.ylabel('$\\theta$ [deg/s]',fontsize=12)

        plt.subplot(5,1,4)
        plt.plot(self.thetadot)
        plt.xlabel('Time Step',fontsize=12)
        plt.ylabel('$\dot{\\theta}$',fontsize=12)

        plt.subplot(5,1,5)
        plt.plot(self.u)
        plt.xlabel('Time Step',fontsize=12)
        plt.ylabel('u',fontsize=12)

        plt.show()
        history = np.zeros((5, self.total_steps))
        history[0,:] = self.x
        history[1,:] = self.xdot
        history[2,:] = self.theta
        history[3,:] = self.thetadot
        history[4,:] = self.u
        joblib.dump(history, self.SAVEDIR)
        print('Saved data')

# choose a controller
if __name__=='__main__':
    run = TVCartpole()
