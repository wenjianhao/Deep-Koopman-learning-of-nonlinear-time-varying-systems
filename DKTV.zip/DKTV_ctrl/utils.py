'''
===================================================================================
Description: Training File
Project: Deep Koopman Representation for Nonlinear Time Varying Systems
Author: Wenjian Hao, Purdue University

Start at: Sep 2021
Last Revision: Jan 2022
===================================================================================
'''

import torch
import control
import joblib

import numpy as np
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

from LNN import LNN
from torchsummary import summary
from matplotlib.colors import to_rgba_array

#=====================
# TVDK Training File
#=====================
class DKTV_training():
    def __init__(self, data_path, data_name, model_saved_name, training_epoch, dim_states, dim_lifting, dim_control, 
                  learning_rate, decay_rate, keep_train, plot_NN):

      self.data_path = data_path
      self.data_name = data_name
      self.model_saved_name = model_saved_name
      self.training_epoch = training_epoch
      self.dim_states = dim_states
      self.dim_lifting = dim_lifting
      self.dim_control = dim_control
      self.learning_rate = learning_rate
      self.keep_train = keep_train
      self.plot_NN = plot_NN   
      self.decay_rate = decay_rate

    def pretrain_model(self, tx, ty, tu):
      # get the training data
      train_samples, train_label, train_u = tx, ty, tu
      training_device = torch.device('cuda:0')
      print('Training device: ', training_device)

      # set parameters
      if self.keep_train:
        load_liftNN = self.data_path + self.model_saved_name
        ckpt_liftNN = torch.load(load_liftNN, map_location='cuda:0')
        lifting = LNN(dim_input=self.dim_states, dim_output=self.dim_lifting)
        lifting.load_state_dict(ckpt_liftNN['model_lifting'])
        print('Keep Training')
      else:
        lifting = LNN(dim_input=self.dim_states, dim_output=self.dim_lifting)
      
      # plot structure
      if self.plot_NN:
          device = torch.device("cuda")
          modellifting = LNN(dim_input=self.dim_states, dim_output=self.dim_lifting).to(device)
          summary(modellifting, (1,self.dim_states))

      #==================================================
      # choose the training optimizer
      #==================================================
      # optimizer = optim.Adam(lifting.parameters(), lr=1e-4, weight_decay = 0.01)
      # optim_decoder = optim.AdamW(decoder.parameters(), lr=1e-3, betas=(0.9, 0.999), eps=1e-08, weight_decay=0.01, amsgrad=False)
      # optim_decoder = optim.Adamax(decoder.parameters(), lr=0.002, betas=(0.9, 0.999), eps=1e-08, weight_decay=0)
      # optim_decoder = optim.Adam(decoder.parameters(), lr=1e-3, betas=(0.9, 0.999), eps=1e-08, weight_decay=0.01, amsgrad=False)
      
      # for converging quickly
      optimizer = optim.Adam(lifting.parameters(), lr=self.learning_rate, weight_decay = self.decay_rate)
      #==================================================
    
      train_loss = []

      # Pass data to the training GPU
      tx, ty, tu = train_samples, train_label, train_u
      trset = torch.t(torch.FloatTensor(tx).to(training_device))
      trlab = torch.t(torch.FloatTensor(ty).to(training_device))
      tru = torch.t(torch.FloatTensor(tu).to(training_device))
      lifting.to(training_device)

      X_lift_table = np.empty(shape=[self.dim_lifting, 0])
      Y_lift_table = np.empty(shape=[self.dim_lifting, 0])
      U_table = np.empty(shape=[self.dim_control, 0])
      XU = []
      # Training
      lifting.train()
      for i in range(self.training_epoch):
          # lifting xt and x(t+1)
          x_t_lift = lifting(trset)
          x_t1_lift = lifting(trlab)

          # M = torch.t(x_t1_lift)@torch.pinverse(torch.cat((torch.t(x_t_lift), torch.t(tru)), 0))
          # M = M.cpu().detach().numpy()
          # A = np.matrix(M[:, 0:self.dim_lifting])
          # B = np.matrix(M[:, self.dim_lifting:(self.dim_lifting+self.dim_control)])

          # #==================================
          # # Calculating A, B matrices
          # #==================================
          # # Initialize the matrix stack for A, B matrices calculation
          x_lift_stack = x_t_lift.cpu().detach().numpy()
          x_t1_lift_stack = x_t1_lift.cpu().detach().numpy()
          u_t = tru.cpu().detach().numpy()   # To do: need to be ensured that if we need a contrains for the initial state
          X_lift_table = np.append(X_lift_table, x_lift_stack.T, axis=1)	  # horizontally concatenation NxK
          Y_lift_table = np.append(Y_lift_table, x_t1_lift_stack.T, axis=1)	# horizontally concatenation NxK
          U_table = np.append(U_table, np.matrix(u_t).T, axis=1)
          # A and B, which can be found in paper 
          # "Linear predictors for nonlinear dynamicalsystems: Koopman operator meets model predictive control"
          XU = np.append(X_lift_table,U_table, axis=0)
          G = XU * (XU.T)
          V = Y_lift_table * (XU.T)
          M = V * np.linalg.pinv(G)    # inv when we have control input

          # get the A,B,C matrix     
          A = M[:, 0:self.dim_lifting]
          B = M[:, self.dim_lifting:(self.dim_lifting+self.dim_control)]
          A_mat = torch.FloatTensor(A).to(training_device)
          B_mat = torch.FloatTensor(B).to(training_device)
          C_mat = torch.matmul(trset.T, torch.pinverse(x_t_lift).T).to(training_device)
          D_mat = torch.zeros(C_mat.shape[0], B_mat.shape[1]).to(training_device)
          AB_mat = torch.cat((A_mat,B_mat),1)
          CD_mat = torch.cat((C_mat, D_mat),1)
          ABCD_mat = torch.cat((AB_mat, CD_mat), 0)
          C = C_mat.cpu().detach().numpy()
          #==================================
          
          # loss1 is the linear lifting loss
          loss1 = self.linearize_loss(ABCD_mat, x_t_lift, x_t1_lift, trset, tru)
          # loss2 ensures a controllable new lifted linear system
          rank, loss2 = self.controllability_loss(A, B, C)
          # loss3 = self.norml(x_t_lift)
          # get the complete loss 
          # total_loss = loss1 + loss2 + loss3
          total_loss = loss1 + loss2 #+ loss3

          optimizer.zero_grad()
          total_loss.backward()
          optimizer.step()

          # plot the training process
          if i % 10 == 0:
            print('Current epoch is: ', i)
            print('Training loss is: %.9f' % (total_loss))
          
          # only saving the model with the lowest loss
          train_loss.append(total_loss.cpu().detach().numpy())
          min_loss = min(train_loss)
          if total_loss.cpu().detach().numpy() <= min_loss:   
              if rank == self.dim_states: # uncomment it if there is control data
                  # save lifting and decoder models
                  state = {'model_lifting': lifting.state_dict()}
                  torch.save(state, (self.data_path+'nnbasis/'+str(0)+self.model_saved_name))
                  print("Saved min loss model, loss: ", total_loss.cpu().detach().numpy())
                  
      # visualize training process
      plt.rcParams['figure.dpi'] = 100
      plt.figure(figsize=(6, 4))
      plt.plot(train_loss, 'b:', label='training loss', linewidth=2.0)
      plt.title('Pretraining', fontsize=12)
      plt.ylabel('Loss', fontsize=12)
      plt.xlabel('Epoch', fontsize=12)
      plt.xticks(fontsize=12)
      plt.yticks(fontsize=12)
      plt.legend(loc='upper right', prop={'size': 10})
      plt.show()
      return A, B, C

    def DKTV(self, Astack, Bstack, tx, ty, tu, num_traj, batchsize, k):
      # get the training data
      train_samples, train_label, train_u = tx, ty, tu
      training_device = torch.device('cuda:0')
      print('Training device: ', training_device)
      # load pretrained DNN
      load_liftNN = self.data_path+'nnbasis/'+str(0)+self.model_saved_name
      ckpt_liftNN = torch.load(load_liftNN, map_location='cuda:0')
      lifting = LNN(dim_input=self.dim_states, dim_output=self.dim_lifting)
      lifting.load_state_dict(ckpt_liftNN['model_lifting'])
      print('Finish loading the pretrained model')
      
      # plot structure
      if self.plot_NN:
          device = torch.device("cuda")
          modellifting = LNN(dim_input=self.dim_states, dim_output=self.dim_lifting).to(device)
          summary(modellifting, (1,self.dim_states))
    
      train_loss = []

      # Pass data to the training GPU
      tx, ty, tu = train_samples, train_label, train_u
      trset = torch.t(torch.FloatTensor(tx).to(training_device))
      trlab = torch.t(torch.FloatTensor(ty).to(training_device))
      tru = torch.t(torch.FloatTensor(tu).to(training_device))
      lifting.to(training_device)
      fixlifting = lifting

      # split the data by time
      xold = trset[0:(trset.size(dim=0)-batchsize*num_traj), :]
      yold = trlab[0:(trlab.size(dim=0)-batchsize*num_traj), :]
      tru_old = tru[0:(tru.size(dim=0)-batchsize*num_traj), :]
      xnew = trset[(trset.size(dim=0)-batchsize*num_traj):, :]
      ynew = trlab[(trset.size(dim=0)-batchsize*num_traj):, :]
      tru_new = tru[(tru.size(dim=0)-batchsize*num_traj):, :]

      # previous solution
      Ap = torch.FloatTensor(Astack[:,:,(k-1)]).to(training_device)
      Bp = torch.FloatTensor(Bstack[:,:,(k-1)]).to(training_device)
      Mp =  torch.cat((Ap, Bp),1)
      x_t_old = fixlifting(xold)
      x_t1_old = fixlifting(yold)
      XU = torch.cat((torch.t(x_t_old), torch.t(tru_old)), 0)
      G = XU@torch.t(XU)

      #==================================================
      # choose the training optimizer
      #==================================================
      # optimizer = optim.Adam(lifting.parameters(), lr=1e-5)
      # optim_decoder = optim.AdamW(decoder.parameters(), lr=1e-3, betas=(0.9, 0.999), eps=1e-08, weight_decay=0.01, amsgrad=False)
      # optim_decoder = optim.Adamax(decoder.parameters(), lr=0.002, betas=(0.9, 0.999), eps=1e-08, weight_decay=0)
      # optim_decoder = optim.Adam(decoder.parameters(), lr=1e-3, betas=(0.9, 0.999), eps=1e-08, weight_decay=0.01, amsgrad=False)
      
      # for converging quickly
      optimizer = optim.Adam(lifting.parameters(), lr=self.learning_rate, weight_decay = self.decay_rate)
      #==================================================

      # Training
      lifting.train()
      for i in range(self.training_epoch):
          # lifting xt and x(t+1)
          x_t_lift = lifting(xnew)
          x_t1_lift = lifting(ynew)          
          
          chinew = torch.cat((torch.t(x_t_lift), torch.t(tru_new)), 0)
          lambdatau = torch.pinverse(torch.eye(chinew.size(dim=1)).to(training_device)+torch.t(chinew)@torch.pinverse(G)@chinew)
          # V = Y_lift_table * (XU.T)
          M = Mp + (torch.t(x_t1_lift) - Mp@chinew)@lambdatau@torch.t(chinew)@torch.pinverse(G)  
          A = M[:, 0:self.dim_lifting]
          B = M[:, self.dim_lifting:(self.dim_lifting+self.dim_control)]
          # C = torch.t(trset)@torch.pinverse(torch.t(xlift_total))
          C = torch.t(xnew)@torch.pinverse(torch.t(x_t_lift))
          D = torch.zeros(C.size(dim=0), B.size(dim=1)).to(training_device)
          # AB_mat = torch.cat((A,B),1)
          CD_mat = torch.cat((C,D),1)

          #========================================
          # Extremely weird bug for pytorch
          ABCD_mat = torch.cat((M, CD_mat), 0)
          ABCD_mat = np.matrix(ABCD_mat.cpu().detach().numpy())
          ABCD_mat = torch.FloatTensor(ABCD_mat).to(training_device)
          #========================================
           
          loss1 = self.linearize_loss(ABCD_mat, x_t_lift, x_t1_lift, xnew, tru_new)
          # # loss2 ensures a controllable new lifted linear system
          Alt = np.matrix(A.cpu().detach().numpy())
          Blt = np.matrix(B.cpu().detach().numpy())
          Clt = np.matrix(C.cpu().detach().numpy())
          rank, loss2 = self.controllability_loss(Alt, Blt, Clt)
          # loss3 = self.norml(x_t_lift)
          # get the complete loss 
          total_loss = loss1 #+ loss2 + loss3

          optimizer.zero_grad()
          total_loss.backward()
          optimizer.step()

          # plot the training process
          if i % 10 == 0:
            print('Current epoch is: ', i)
            print('Training loss is: %.9f' % (total_loss))

          # only saving the controllable model with the lowest loss
          train_loss.append(total_loss.cpu().detach().numpy())
          min_loss = min(train_loss)
          if total_loss.cpu().detach().numpy() <= min_loss:   
              if rank == self.dim_states:
                  # save lifting and decoder models
                  state = {'model_lifting': lifting.state_dict()}
                  torch.save(state, (self.data_path+'nnbasis/'+str(k)+self.model_saved_name))
                  print("Saved min loss model, loss: ", total_loss.cpu().detach().numpy())

      return A.cpu().detach().numpy(), B.cpu().detach().numpy(), C.cpu().detach().numpy()

    #=====================
    # Data process
    #=====================
    def data_process(self, split):
      data = joblib.load(self.data_name)
      Z = data[0:(self.dim_states+self.dim_control),:]
      X = np.zeros((Z.shape[0],0))
      Y = np.zeros((Z.shape[0],0))
      X = np.append(X, Z[:,0:-2], 1)  # X_t
      Y = np.append(Y, Z[:,1:-1], 1)  # X_(t+1)

      samples = X[0:(self.dim_states), :]
      label = Y[0:(self.dim_states), :]
      U_control = X[self.dim_states:(self.dim_states+self.dim_control), :]

      # split data
      train_len = int(0.8*len(label[0]))
      totalen = len(X[0])
      train_samples = samples[:, 0:(train_len)]
      train_label = label[:, 0:(train_len)]
      train_u = U_control[:, 0:(train_len)]
      valid_samples = samples[:, train_len:totalen]
      valid_label = label[:, train_len:totalen]
      valid_u = U_control[:, train_len:totalen]
      
      if split:
        return train_samples, train_label, train_u, valid_samples, valid_label, valid_u
      else:
        return samples

    #=====================
    # loss functions
    #=====================
    # def linearize_loss(self, A_mat, B_mat, x_t_lift, x_t1_lift, tru):
    #   prediction = A_mat @ torch.transpose(x_t_lift,0,1) + B_mat @ torch.transpose(tru,0,1)
    #   lossfunc = torch.nn.MSELoss()
    #   loss1 = lossfunc(prediction, torch.transpose(x_t1_lift,0,1))
    #   return loss1

    def linearize_loss(self, ABCD_mat, x_t_lift, x_t1_lift, xnew, tru):
      label = torch.cat((x_t1_lift.T, xnew.T), 0)
      trainset = torch.cat((x_t_lift.T, tru.T), 0)
      prediction = ABCD_mat @ trainset
      lossfunc = torch.nn.MSELoss()
      loss1 = lossfunc(prediction, label)
      return loss1

    def controllability_loss(self, A, B, C):
      ctrb = control.ctrb(C*A*np.linalg.pinv(C), C*B)
      rank = np.linalg.matrix_rank(ctrb)
      loss2 = self.dim_states - rank
      return rank, loss2

    def norml(self, A):
      loss = torch.abs(1-torch.norm(A)/A.size(dim=0))
      return loss