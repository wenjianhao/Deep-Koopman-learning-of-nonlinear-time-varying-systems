# Tests
```
pip install odmd
pip install -r requirements.txt
python -m pytest .
```
For demo of these algorithms on 2D linear time-varying system, see `/demo` directory.