'''
===================================================================================
Description: Optimal Control Algorithm for Nonlinear Time Varying Systems
Project: Deep Koopman Representation for Nonlinear Time Varying Systems
Author: Wenjian Hao, Purdue University

Start at: Sep 2021
Last Revision: Jan 2022

Training data format:

 | x11 x12 ... x1t |
 | x21 x12 ... x1t |
 | ... ... ... ... |
 | xn1 xn2 ... xnt |
 | u11 u12 ... u1t |
 | ... ... ... ... |
 | um1 um2 ... umt |

 n: dimension of the states
 m: dimension of the control
 t: time series 
===================================================================================
'''

#=====================
# Load third packages
#=====================
import os
import argparse
import joblib
import numpy as np
from utils import DKTV_training
from data_generation import TVCartpole
import matplotlib.pyplot as plt

#=====================
# Action
#=====================
train = True                            # Decide to start training or not
keep_train =  False   #   True          # Keep training based on the previous model
plot_NN = False                         # Plot the structure of the lifting network and the decoder network

#=====================
# Set parameters
#=====================
'''
All results will be saved in /SavedResults
please define the DNN basis path in file utils.py
'''
if not os.path.exists("./SavedResults"):
    os.makedirs("./SavedResults")
results_path = 'SavedResults/'
data_name = 'SavedResults/trainingdata.pkl'
model_saved_name = 'liftnetwork.pth'
fileastack = 'SavedResults/Astack.pkl'
filebstack = 'SavedResults/Bstack.pkl'
filecstack = 'SavedResults/Cstack.pkl'
# training superparameters
parser = argparse.ArgumentParser()
parser.add_argument("--dim_states", default=4, type=int)            # dimension of system states
parser.add_argument("--dim_lifting", default=10, type=int)          # dimension of the lifting
parser.add_argument("--dim_control", default=1, type=int)           # dimension of the control
# pretrain
parser.add_argument("--prebatch_size", default=10)   
parser.add_argument("--pretraining_epoch", default=500, type=int)      # training epoch
parser.add_argument("--prelearning_rate", default=1e-3)                # learning rate of the optimizer
parser.add_argument("--predecay_rate", default=1e-4)                   # training decay rate of the optimizer
# DKTV
parser.add_argument("--training_epoch", default=500, type=int)      # training epoch
parser.add_argument("--learning_rate", default=1e-3)                # learning rate of the optimizer
parser.add_argument("--decay_rate", default=1e-5)                   # training decay rate of the optimizer
parser.add_argument("--batch_size", default=10)              
args = parser.parse_args()

# data generation
num_traj = 20
TVCartpole(num_traj)
# if not os.path.exists("./SavedResults/trainingdata.pkl"):
#   print('No training data, start collecting')
#   TVCartpole(num_traj)
# data processing
data = joblib.load(data_name)
trj_len = int(data.shape[1]/num_traj)
num_dyn = int(np.floor((trj_len - args.prebatch_size)/args.batch_size) + 1)
Z = data[0:(args.dim_states+args.dim_control),:]
X = np.zeros((Z.shape[0],0))
Y = np.zeros((Z.shape[0],0))
for i in range(num_traj):
  X = np.append(X, Z[:,i*trj_len:((i+1)*trj_len-1)], 1)
  Y = np.append(Y, Z[:,(i*trj_len+1):((i+1)*trj_len)], 1)
samples = X[0:(args.dim_states), :]
label = Y[0:(args.dim_states), :]
U_control = X[args.dim_states:(args.dim_states+args.dim_control), :]
# dynamic stacks for time varying systems
Astack = np.empty((args.dim_lifting, args.dim_lifting, num_dyn))
Bstack = np.empty((args.dim_lifting, args.dim_control, num_dyn))
Cstack = np.empty((args.dim_states, args.dim_lifting, num_dyn))
evaleigenv = np.empty((args.dim_states, num_dyn), dtype=complex)

#=====================
# Pretraining
#=====================
aftrj_len = int(trj_len - 1)
prex = np.zeros((samples.shape[0],0))
prey = np.zeros((label.shape[0],0))
preu = np.zeros((U_control.shape[0],0))
for i in range(num_traj):
  prex = np.append(prex, samples[:, i*aftrj_len:(i*aftrj_len+args.prebatch_size)], 1)
  prey = np.append(prey, label[:, i*aftrj_len:(i*aftrj_len+args.prebatch_size)], 1)
  preu = np.append(preu, U_control[:, i*aftrj_len:(i*aftrj_len+args.prebatch_size)], 1)

DKTV = DKTV_training(results_path, data_name, model_saved_name, 
                      args.pretraining_epoch, args.dim_states, 
                      args.dim_lifting, args.dim_control,
                      args.prelearning_rate, args.predecay_rate, keep_train, plot_NN)
# presol
A0, B0, C0 = DKTV.pretrain_model(prex, prey, preu)
Astack[:,:,0] = A0
Bstack[:,:,0] = B0
Cstack[:,:,0] = C0
evaleigenv[:,0] = np.linalg.eigvals(C0*A0*(np.linalg.pinv(C0)))
print('Learned eigenvalue is: ', evaleigenv[:,0])

#=====================
# TVDK
#=====================
# real time dynamic tracking
DKTV = DKTV_training(results_path, data_name, model_saved_name, 
                      args.training_epoch, args.dim_states, 
                      args.dim_lifting, args.dim_control,
                      args.learning_rate, args.decay_rate, keep_train, plot_NN)

xtrain = np.zeros((samples.shape[0],0))
ytrain = np.zeros((label.shape[0],0))
utrain = np.zeros((U_control.shape[0],0))
xtrain = np.append(xtrain, prex, 1)
ytrain = np.append(ytrain, prey, 1)
utrain = np.append(utrain, preu, 1)

for k in range(1,num_dyn):
  xtemp = np.zeros((samples.shape[0],0))
  ytemp = np.zeros((label.shape[0],0))
  utemp = np.zeros((U_control.shape[0],0))
  for i in range(num_traj):
    xtemp = np.append(xtemp, samples[:, (i*aftrj_len+args.prebatch_size+k*args.batch_size):(i*aftrj_len+args.prebatch_size+(k+1)*args.batch_size)], 1)
    ytemp = np.append(ytemp, label[:, (i*aftrj_len+args.prebatch_size+k*args.batch_size):(i*aftrj_len+args.prebatch_size+(k+1)*args.batch_size)], 1)
    utemp = np.append(utemp, U_control[:, (i*aftrj_len+args.prebatch_size+k*args.batch_size):(i*aftrj_len+args.prebatch_size+(k+1)*args.batch_size)], 1)
  xtrain = np.append(xtrain, xtemp, 1)
  ytrain = np.append(ytrain, ytemp, 1)
  utrain = np.append(utrain, utemp, 1)

  Ak, Bk, Ck = DKTV.DKTV(Astack, Bstack, xtrain, ytrain, utrain, num_traj, args.batch_size, k)
  evaleigenv[:, k] = np.linalg.eigvals(np.matrix(Ck)*np.matrix(Ak)*(np.linalg.pinv(np.matrix(Ck))))
  Astack[:,:,k] = Ak
  Bstack[:,:,k] = Bk
  Cstack[:,:,k] = Ck

# Save dyn stacks
joblib.dump(Astack, fileastack)
joblib.dump(Bstack, filebstack)
joblib.dump(Cstack, filecstack)
# plot
plt.rcParams['figure.dpi'] = 100
plt.figure(figsize=(6, 4))
# plt.rc('text', usetex=True)
# plt.rc('font', family='serif')
plt.title('Learned Dynamics', fontsize=12)
plt.plot(evaleigenv[0, :], 'g-.', label='Window, w=10', linewidth=2.0)
plt.tick_params(labelsize=12)
plt.xlabel('batch$^{th}$', fontsize=12)
plt.ylabel('Im($\lambda$)', fontsize=12)
plt.legend(loc='best', fontsize=10, shadow=True)
# plt.xlim([0, 10])
# plt.ylim([1, 2])
plt.show()
