r = 100;
theta = 38*pi/180;
a1 = pi/2% - theta/2;
a2 = a1 + theta;
t = linspace(a1, a2);
x0 = 0;
y0 = 0;
x = x0 + r*cos(t);
y = y0 + r*sin(t);
x1 = x0 + 50*cos(t);
y1 = y0 + 50*sin(t);
fill([x0,(x-x1),y0],[y0,(y-y1),y0],'r','EdgeColor','none')
% fill([x0,(x),y0],[y0,(y),y0],'blue','EdgeColor','none')