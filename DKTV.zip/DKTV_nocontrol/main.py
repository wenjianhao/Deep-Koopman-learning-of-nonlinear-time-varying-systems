'''
===================================================================================
Description: Optimal Control Algorithm for Nonlinear Time Varying Systems
Project: Deep Koopman Representation for Nonlinear Time Varying Systems
Author: Wenjian Hao, Purdue University

Start at: Sep 2021
Last Revision: Jan 2022

Training data format:

 | x11 x12 ... x1t |
 | x21 x12 ... x1t |
 | ... ... ... ... |
 | xn1 xn2 ... xnt |
 | u11 u12 ... u1t |
 | ... ... ... ... |
 | um1 um2 ... umt |

 n: dimension of the states
 m: dimension of the control
 t: time series 
===================================================================================
'''

#=====================
# Load third packages
#=====================
import os
import argparse

import numpy as np
import matplotlib.pyplot as plt

from SimEnvs import ToyEx
from odmd import WindowDMD
from utils import DKTV_training
#=====================
# Action
#=====================
train = True                            # Decide to start training or not
keep_train =  False   #   True          # Keep training based on the previous model
plot_NN = False                         # Plot the structure of the lifting network and the decoder network

#=====================
# Set parameters
#=====================
if not os.path.exists("./SavedResults"):
    os.makedirs("./SavedResults")

results_path = 'SavedResults/'
data_name = 'data_collecting/data/trainingdata.pkl'
model_saved_name = 'liftnetwork.pth'
parser = argparse.ArgumentParser()
parser.add_argument("--dim_states", default=2, type=int)            # dimension of system states
parser.add_argument("--dim_lifting", default=10, type=int)          # dimension of the lifting
# pretrain
parser.add_argument("--prebatch_size", default=100)   
parser.add_argument("--pretraining_epoch", default=500, type=int)      # training epoch
parser.add_argument("--prelearning_rate", default=1e-3)                # learning rate of the optimizer
parser.add_argument("--predecay_rate", default=1e-4)                   # training decay rate of the optimizer
# DKTV
parser.add_argument("--training_epoch", default=200, type=int)      # training epoch
parser.add_argument("--learning_rate", default=1e-3)                # learning rate of the optimizer
parser.add_argument("--decay_rate", default=1e-4)                   # training decay rate of the optimizer
parser.add_argument("--batch_size", default=10)              
args = parser.parse_args()

#=====================
# Data generation
#=====================
x0 = [1, 0]
dt = 0.1
SimTime = 20
env = ToyEx(x0, SimTime, dt)
x, y, groundtruth = env.sim()
# split data
train_len = int(0.8*len(x[0]))
totalen = len(x[0])
train_samples = x[:, 0:(train_len)]
train_label = y[:, 0:(train_len)]
valid_samples = x[:, train_len:totalen]
valid_label = y[:, train_len:totalen]
# recording
Astack = np.empty((args.dim_lifting, args.dim_lifting, len(train_samples[0])))
evaleigenv = np.empty((args.dim_states, len(train_samples[0])), dtype=complex)
tspan = np.linspace(0, SimTime, int(SimTime/dt+1))
plott = tspan[1:]

#=====================
# TVDMD
#=====================
AminibatchDMD = np.empty((args.dim_states, args.dim_states, len(train_samples[0])))
evalsminibatchDMD = np.empty((args.dim_states, len(train_samples[0])), dtype=complex)
for k in range(args.batch_size, len(train_samples[0])):
    AminibatchDMD[:, :, k] = y[:, k-args.batch_size+1:k+1].dot(np.linalg.pinv(x[:, k-args.batch_size+1:k+1]))
    evalsminibatchDMD[:, k] = np.log(np.linalg.eigvals(AminibatchDMD[:, :, k]))/dt
# # visualize true, batch, window
# plt.rcParams['figure.dpi'] = 100
# plt.figure(figsize=(6, 4))
# # plt.rc('text', usetex=True)
# # plt.rc('font', family='serif')
# plt.title('Time Varying DMD', fontsize=12)
# plt.plot(plott[args.prebatch_size:train_len], np.imag(evalsminibatchDMD[0, args.prebatch_size:train_len]), 'g-.',
#          label='Window, w=10, wf=1', linewidth=2.0)
# plt.tick_params(labelsize=12)
# plt.xlabel('Time', fontsize=12)
# plt.ylabel('Im($\lambda_{DMD}$)', fontsize=12)
# plt.legend(loc='best', fontsize=10, shadow=True)
# # plt.xlim([0, 10])
# # plt.ylim([1, 2])
# plt.show()
plt.rcParams['figure.dpi'] = 100
plt.figure(figsize=(6, 4.3))
plt.rc('text', usetex=True)
plt.rc('font', family='serif')
plt.plot(plott[(args.prebatch_size+1):train_len], x[0, (args.prebatch_size+1):train_len], 'g-.',
         label='$x_1(t)$', linewidth=2.0)
plt.plot(plott[(args.prebatch_size+1):train_len], x[1, (args.prebatch_size+1):train_len], 'b--.',
         label='$x_2(t)$', linewidth=2.0)
plt.tick_params(labelsize=12)
plt.xlabel('Time', fontsize=12)
plt.ylabel('State', fontsize=12)
plt.legend(loc='best', fontsize=10, shadow=True)
plt.grid()
# plt.show()

#=====================
# Pretraining
#=====================
DKTV = DKTV_training(results_path, data_name, model_saved_name, 
                      args.pretraining_epoch, args.dim_states, 
                      args.dim_lifting, args.prelearning_rate, args.predecay_rate, keep_train, plot_NN)

# presol
A0, C0 = DKTV.pretrain_model(train_samples[:, 0:args.prebatch_size], train_label[:, 0:args.prebatch_size], 
                valid_samples[:, 0:args.prebatch_size], valid_label[:, 0:args.prebatch_size])
Astack[:,:,args.prebatch_size] = A0
# evaleigenv[:,args.prebatch_size] = np.log(np.linalg.eigvals(C0.dot(A0).dot(np.linalg.pinv(C0))))/dt
evaleigenv[:,args.prebatch_size] = np.linalg.eigvals(C0.dot(A0).dot(np.linalg.pinv(C0)))
print('Pre-approximated eigen: ', evaleigenv[:,args.prebatch_size])
print('True eigen: ', groundtruth[:,args.prebatch_size])

#=====================
# DKTV
#=====================
# real time dynamic tracking
DKTV = DKTV_training(results_path, data_name, model_saved_name, 
                      args.training_epoch, args.dim_states, 
                      args.dim_lifting, args.learning_rate, args.decay_rate, keep_train, plot_NN)
for k in range(args.prebatch_size+1, len(train_samples[0])):
  if k % args.batch_size == 0:
    train_samples = train_samples[:, 0:k]
    train_label = train_label[:, 0:k]
    valid_samples = valid_samples[:, 0:k]
    valid_label = valid_label[:, 0:k]
    Ak, Ck = DKTV.DKTV(Astack, train_samples, train_label, 
              valid_samples, valid_label, args.batch_size)
    # evaleigenv[:, k] = np.log(np.linalg.eigvals(Ck.dot(Ak).dot(np.linalg.pinv(Ck))))/dt
    evaleigenv[:, k] = np.linalg.eigvals(Ck.dot(Ak).dot(np.linalg.pinv(Ck)))
    Astack[:,:,k] = Ak
    # print('k is: ', k)


value = []
plottcut = []
for i in range(len(np.imag(evaleigenv[0, args.prebatch_size:]))):
  if np.imag(evaleigenv[0, args.prebatch_size+i]) != 0:
    value.append(np.imag(evaleigenv[0, args.prebatch_size+i]))
    plottcut.append(plott[args.prebatch_size+i])

plt.rcParams['figure.dpi'] = 100
plt.figure(figsize=(6, 4.3))
plt.rc('text', usetex=True)
plt.rc('font', family='serif')
# plt.title('Time Varying Nonlinear Dynamic Approximation', fontsize=12)
plt.plot(plott[args.prebatch_size:train_len], np.imag(groundtruth[0, args.prebatch_size:train_len]), 'k-', label='True', linewidth=2.0)
# plt.plot(plottcut[1:], np.log(value[1:])/dt, 'y-.', label='log, batch=10', linewidth=2.0)
plt.plot(plottcut[1:], value[1:], 'g-.', label='DKTV, batch=10', linewidth=2.0)
plt.plot(plott[(args.prebatch_size+1):train_len], np.imag(evalsminibatchDMD[0, (args.prebatch_size+1):train_len]), 'r--.',
         label='Time Varying DMD, batch=10', linewidth=2.0)
plt.tick_params(labelsize=12)
plt.xlabel('Time', fontsize=12)
plt.ylabel('Im($\lambda$)', fontsize=12)
plt.legend(loc='best', fontsize=10, shadow=True)
# plt.xlim([0, 10])
# plt.ylim([1, 2])
plt.show()
