plt.xlim([0, 10])
# plt.ylim([1, 2])